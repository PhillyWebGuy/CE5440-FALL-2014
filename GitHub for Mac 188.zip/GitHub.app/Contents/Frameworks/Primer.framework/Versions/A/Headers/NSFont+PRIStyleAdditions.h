//
//  NSFont+PRIStyleAdditions.h
//  Primer
//
//  Created by Justin Spahr-Summers on 2013-07-01.
//  Copyright (c) 2013 GitHub. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSFont (PRIStyleAdditions)
@end
